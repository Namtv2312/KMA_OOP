/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception_1_Date;

/**F
 *
 * @author Administrator
 */
public class main {

    public static void main(String[] args) {
        NhanVien nv1 = new NhanVien();
        nv1.nhap();
        System.out.println(nv1.toString());
    }
}
